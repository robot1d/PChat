### TODO

#### Features to be implemented

* deeper WebVTT support (alignment, color, etc.) - include captionator
* Full support for Ender.js, including mediaelement-and-player-standalone which includes ender.
* thin line when controls are off
* system-wide events
* Ogg/Theora playback
* Better alignment with native MediaElement (using shimichanga.com techniques)

*More items listed in https://github.com/johndyer/mediaelement/labels/Feature*


#### Known issues

*Known issues to be resolved listed in https://github.com/johndyer/mediaelement/labels/Bug*